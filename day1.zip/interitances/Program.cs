﻿namespace interitances
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Manager manager = new Manager(126534,"peter","india",237844,65000);
            Console.WriteLine("Manager salary : ");
            manager.calulatesalary();
            manager.calulatetransportallowance();
            Trainee trainee = new Trainee(29846, "anita", "india", 442085, 45000);
            Console.WriteLine("Trainee salary : ");
            trainee.calulatesalary();
            trainee.calulatetransportallowance();

        }
    }
}
