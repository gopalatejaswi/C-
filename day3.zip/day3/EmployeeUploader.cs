﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using System.Data;


namespace day3
{
    public class EmployeeUploader
    {
        /*
        public String connectionstring= "Server=b7e524e56c995ea\\SQLEXPRESS" +
                    "Database=master;Trusted_Connection=True;" +
                    "Initial Catalog=trainingDB;pooling=False;" + "Encrypt=False;Trust Server Certificate=False";
        */

        public void StoreDepartmentsDetails(int id,String name,String head,String Description)
        {
            using (SqlConnection conn = Dbhelp.GetConnection())
            {
                conn.Open();
                String query = "insert into Depart(Departmentid ,Departmentname,Departmenthead,Departmentdescription)" +
                    "values(@id,@name,@head,@description)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@head", head);
                    cmd.Parameters.AddWithValue("@description", Description);
                    cmd.ExecuteNonQuery();

                    Console.WriteLine("Department Added successfully.");
                }
            }
        }
        public void StoreEmployeeDetails(int id, String name, String address, decimal salary,long contactno,int departmentId)
        {
            using (SqlConnection conn = Dbhelp.GetConnection()) 
            {
                conn.Open();
                String query = "insert into Employee(Employeeid,Employeename,Employeeaddress,Employeesalary,Employeecontactno,Departmentid)" +
                    "values(@id,@name,@address,@salary,@contactno,@departmentid);";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@address", address);
                    cmd.Parameters.AddWithValue("@salary", salary);
                    cmd.Parameters.AddWithValue("@contactno", contactno);
                    cmd.Parameters.AddWithValue("@departmentid", departmentId);
                    cmd.ExecuteNonQuery();

                    Console.WriteLine("Employee Added successfully.");
                }
            }
        }
        public void RetriveEmployeeDetails(int employeeid)
        {
            using (SqlConnection conn = Dbhelp.GetConnection()) 
            {
                conn.Open();
                String query = @"select e.Employeeid,e.Employeename,e.Employeecontactno,e.Employeeaddress,
                    d.Departmentname,d.Departmenthead
                    from Employee e
                    join Depart d ON e.Departmentid=d.Departmentid
                    WHERE e.Employeeid= @employeeid;";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@employeeid", employeeid);
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            Console.WriteLine($"Employee id : {reader["Employeeid"]}");
                            Console.WriteLine($"Employee name : {reader["Employeename"]}");
                            Console.WriteLine($"Employee contact number : {reader["Employeecontactno"]}");
                            Console.WriteLine($"Employee address : {reader["Employeeaddress"]}");
                            Console.WriteLine($"Department name : {reader["Departmentname"]}");
                            Console.WriteLine($"Department head : {reader["Departmenthead"]}");
                        }
                        else
                        {
                            Console.WriteLine("Employee id is not present");
                        }
                    }
                }
            }

        }
        public void calculatepfamount(int employeeid)
        {
            using (SqlConnection conn = Dbhelp.GetConnection())
            {
                SqlCommand cmd = new SqlCommand("CalculatePF", conn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@employeeid", employeeid);
                cmd.Parameters.Add("@pfAmount", System.Data.SqlDbType.Decimal).Direction = System.Data.ParameterDirection.Output;

                conn.Open();
                cmd.ExecuteNonQuery();
                decimal pfAmount = Convert.ToDecimal(cmd.Parameters["@pfAmount"].Value);
                conn.Close();

                Console.WriteLine($"Employee PF amount is: {pfAmount}");
            }
        }
    }
}
