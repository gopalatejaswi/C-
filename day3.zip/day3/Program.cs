﻿namespace day3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            EmployeeUploader employeeUploader = new EmployeeUploader();
            
            //employeeUploader.StoreDepartmentsDetails(1, "accounts", "parth", "account depts");
            //employeeUploader.StoreDepartmentsDetails(2, "admin", "purvi", "admin depts");
            //employeeUploader.StoreDepartmentsDetails(3, "hr", "tejaswi", "hr depts");
            //employeeUploader.StoreDepartmentsDetails(4, "sales", "vaishu", "sales depts");

            //employeeUploader.StoreEmployeeDetails(1, "pratham", "123 elm rt", 5000, 1234567890, 1);
            //employeeUploader.StoreEmployeeDetails(2, "piyush", "456 oke er", 12000, 9876543210, 2);
            

            employeeUploader.RetriveEmployeeDetails(1);
            employeeUploader.calculatepfamount(1);
        }
    }
}
