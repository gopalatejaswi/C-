﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Country
{
    internal class CountrySet
    {
        private HashSet<String> H1=new HashSet<String>();   
        public void StoreCountryName(String countryName)
        {
            H1.Add(countryName);
        }
        public String RetriveCountry(String countryName)
        {
            return H1.Contains(countryName) ? countryName : "NON";
        }

    }
}
