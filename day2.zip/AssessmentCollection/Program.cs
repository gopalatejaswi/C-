﻿namespace AssessmentCollection
{
    internal class Program
    {
        static void Main(string[] args)
        {
            EvenNumbers en=new EvenNumbers();
            en.StoreEvenNumbers(10);
            en.PrimeNumbers();
            Console.WriteLine(en.RetriveNumber(4));
            Console.WriteLine(en.RetriveNumber(5));
        }
    }
}
