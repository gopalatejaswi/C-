﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interitances
{
    public class Employee
    {
        public long EmployeeId {  get; set; }
        public String EmployeeName { get; set; }
        public String EmployeeAddress {  get; set; }
        public long EmployeePhone {  get; set; }
        public double basicsalary {  get; set; }
        public double specialallowance { get; set; } = 250.80;
        public double hra { get; set; } = 1000.50;

        public Employee(long id, string name, String address, long phone)
        {
            EmployeeId = id;
            EmployeeName = name;    
            EmployeeAddress = address;
            EmployeePhone = phone;
        }

        public void calulatesalary()
        {
            double salary=basicsalary+(basicsalary*specialallowance/100)+(basicsalary*hra/100);
            Console.WriteLine("salary : "+salary);
        }

        public virtual void calulatetransportallowance()
        {
            double transportallowance = 0.15 * basicsalary;
            Console.WriteLine("transport allowance : "+transportallowance);
        }
    }
}
