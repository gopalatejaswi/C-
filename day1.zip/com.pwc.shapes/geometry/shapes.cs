﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using com.pwc.shapes.shapes;

namespace com.pwc.shapes.geometry
{
    public class shapes
    {
        public static void Main(string[] args)
        {
            Circle circle1 = new Circle();
            Console.WriteLine("the radius of the circle : "+circle1.getradius());

            Circle circle2=new Circle(3.5f);
            Console.WriteLine("the radius of the circle : " + circle2.getradius());
            Console.WriteLine("the pi of the circle" + circle2.getpi());

            Circle circle = new Circle(3.5f,3.14f);
            Console.WriteLine("The radius of the circle : " + circle.getradius());
            Console.WriteLine("The pi of the circle " + circle.getpi());
            float area = circle.calulatecirclearea(5.0f);
            Console.WriteLine("the area of the circle : " + area);
            float circumference = circle.calulatecircumference(5.0f);
            Console.WriteLine("the circumference of the circle : " + circumference);

            /*
            Circle circle2 = new Circle(3.0f);
            Console.WriteLine("circle2 internel constructor: ");
            Console.WriteLine("radius: " + 3.0f);
            Console.WriteLine("Area: " + circle2.calulatecirclearea(1.3f));
            Console.WriteLine("circumference: " + circle2.calulatecircumference(1.3f));
            */
        }
    }
}
