﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interitances
{
    public class Manager : Employee
    {
        public Manager(long id, string name, string address, long phone, double salary) : base(id, name, address, phone)
        {
            basicsalary = salary;
        }

        public override void calulatetransportallowance()
        {
            base.calulatetransportallowance();
        }
    }
}
