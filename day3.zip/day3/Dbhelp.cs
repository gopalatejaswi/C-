﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace day3
{
    class Dbhelp
    {
        private static string connectionString = "Server = b7e524e56c995ea\\SQLEXPRESS;Database=master;Trusted_Connection=True;" + "Initial Catalog = trainingDB;Pooling=False;" + "Encrypt=False; Trust Server Certificate = False";
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(connectionString);
        }
    }
}
