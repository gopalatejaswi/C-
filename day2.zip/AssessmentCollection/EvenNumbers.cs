﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AssessmentCollection
{
    internal class EvenNumbers
    {
        private List<int> A1;
        private List<int> A2;
        public List<int> StoreEvenNumbers(int N)
        {
            A1= new List<int>();
            for(int i=2;i<=N;i+=2)
            {
                A1.Add(i);
            }
            return A1;
        }
        public List<int> PrimeNumbers()
        {
            A2=new List<int>();
            foreach(int num in A1)
            {
                int multipliedvalue = num * 2;
                Console.WriteLine(multipliedvalue+" ");
                A2.Add(multipliedvalue);    
            }
            Console.WriteLine();
            return A2;
        }
        public int RetriveNumber(int N)
        {
            return A1.Contains(N)?N:0;
        }
    }
}
