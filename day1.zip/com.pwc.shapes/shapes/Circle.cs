﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace com.pwc.shapes.shapes
{
    internal class Circle
    {
        private float radius;
        //private float pi;
        internal float pi;

        //construtor1
        public Circle()
        {
            this.radius = 1.5f;
            this.pi = 3.14159f;

        }
        //constructor2
        internal Circle(float radius) : this(radius, 3.14159f)
        {

        }
        /*
        public Circle(float radius) : this(radius,3.14f)
        {

        }
        
        public Circle(float radius)
        {
            this.radius = radius;
            this.pi = 3.14158f;
        }
        
        public Circle(float radius) : this(radius,3.14159f)
        {

        }
        
       
        */

        //constructor3
        public Circle(float radius,float pi)
        {
            this.radius = radius;
            this.pi = pi;
        }

        public float getradius()
        {
            return this.radius;
        }
        public float getpi()
        {
            return this.pi;
        }

        //method to calulate circle area
        public float calulatecirclearea(float radius)
        {
            return this.pi * radius*radius;
        }

        //method to calulate circumference
        public float calulatecircumference(float radius)
        {
            return 2 * this.pi * radius;
        }
    }
}
